Getting started
===============

 

With Routines
-------------



With Jupyter Notebooks
----------------------


